Se recomienda leer el readme que esta en el repositorio de git hub para el correcto funcionamiento del programa.

Además se adjunta el link que direcciona al repositorio de GitHub.


Link repositorio git hub:

https://github.com/Sabar3003/Segundo-Proyecto-Intro-a-progra.git
